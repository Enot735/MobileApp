package com.example.fivethings;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Read12Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.read12);
    }
    public void read(View view)
    {
        Intent intent = new Intent(this,ReadActivity.class);
        startActivity(intent);
    }

    public void menu(View view)
    {
        Intent intent = new Intent(this,MenuActivity.class);
        startActivity(intent);
    }

    public void time(View view)
    {
        Intent intent = new Intent(this,TimeActivity.class);
        startActivity(intent);
    }


}
