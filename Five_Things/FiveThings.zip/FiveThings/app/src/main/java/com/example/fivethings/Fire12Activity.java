package com.example.fivethings;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Fire12Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fire12);
    }
    public void menu(View view)
    {
        Intent intent = new Intent(this,MenuActivity.class);
        startActivity(intent);
    }
    public void fire11(View view)
    {
        Intent intent = new Intent(this,Fire11Activity.class);
        startActivity(intent);
    }
    public void fire13(View view)
    {
        Intent intent = new Intent(this,Fire13Activity.class);
        startActivity(intent);
    }
}
