package com.example.fivethings;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Fire1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fire1);
    }
    public void menu(View view)
    {
        Intent intent = new Intent(this,MenuActivity.class);
        startActivity(intent);
    }
    public void fire11(View view)
    {
        Intent intent = new Intent(this,Fire11Activity.class);
        startActivity(intent);
    }
}
