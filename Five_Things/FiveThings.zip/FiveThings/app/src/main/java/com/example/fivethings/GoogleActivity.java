package com.example.fivethings;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class GoogleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.google);
    }


       public void googleStart(View view)
    {
        Intent intent = new Intent(this,Google21Activity.class);
        startActivity(intent);
    }
    public void menu(View view)
    {
        Intent intent = new Intent(this,MenuActivity.class);
        startActivity(intent);
    }
}
